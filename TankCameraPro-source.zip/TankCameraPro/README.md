# Tank Camera Pro v0.1

Native Camera2 Android app, designed as an initial hardware-compatibility build for the Unihertz Tank 2 Pro.

## Current functions
- Rear camera preview
- Largest JPEG capture size advertised to Camera2
- JPEG quality request 100
- Autofocus, autoexposure and exposure compensation
- Save photos to Pictures/TankCameraPro via MediaStore
- Camera2 diagnostic report including RAW capability

## Important limits
This is a first untested prototype, not a verified Tank 2 Pro APK. Camera2 may expose lower resolutions than the manufacturer's stock camera. JPEG quality 100 is a request, not a guarantee of lossless output. RAW, HDR stacking, night stacking, IR-camera selection, and advanced video are not yet implemented.

## Build an APK without local Android Studio
1. Create a new private GitHub repository.
2. Upload the CONTENTS of this directory (including .github/workflows/build-apk.yml).
3. Open Actions -> Build Tank Camera Pro APK -> Run workflow.
4. When successful, download the `TankCameraPro-debug-apk` artifact.
5. Unzip it and install `app-debug.apk` on the phone. You may need to allow installing apps from that source.

Alternatively, open the project in Android Studio with JDK 17 and build a debug APK.

## Testing
Check camera permission, live preview, photo capture, saved images, and INFO diagnostics. Send the diagnostic results for hardware-specific development.
