package com.tankcamerapro.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.*;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.net.Uri;
import android.util.Size;
import android.view.*;
import android.widget.*;
import java.nio.ByteBuffer;
import java.util.*;

public class MainActivity extends Activity {
    private TextureView preview;
    private TextView status;
    private CameraManager manager;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader reader;
    private HandlerThread worker;
    private Handler handler;
    private String cameraId;
    private Size jpegSize;
    private CaptureRequest.Builder repeating;
    private boolean busy = false;
    private int exposure = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(14,22,29));
        TextView title = new TextView(this); title.setText("TANK CAMERA PRO"); title.setTextColor(Color.WHITE);
        title.setTextSize(22); title.setPadding(22,25,16,20); root.addView(title);
        status = new TextView(this); status.setTextColor(Color.LTGRAY); status.setPadding(18,8,18,8);
        status.setText("Kamera wird vorbereitet …"); root.addView(status);
        preview = new TextureView(this); root.addView(preview, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(5,16,5,24);
        Button minus = button("EV −"); Button shot = button("● FOTO"); Button plus = button("EV +"); Button info = button("INFO");
        controls.addView(minus); controls.addView(shot); controls.addView(plus); controls.addView(info); root.addView(controls);
        setContentView(root);
        manager = (CameraManager)getSystemService(CAMERA_SERVICE);
        minus.setOnClickListener(v -> setExposure(exposure-1));
        plus.setOnClickListener(v -> setExposure(exposure+1));
        shot.setOnClickListener(v -> capture());
        info.setOnClickListener(v -> showDiagnostics());
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){ startCamera(); }
            public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s){ closeCamera(); return true; }
            public void onSurfaceTextureUpdated(SurfaceTexture s){}
        });
        if (Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA},10);
    }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(12); return b; }
    private void message(String s){ runOnUiThread(()->status.setText(s)); }
    private void startCamera(){
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        try {
            if(worker==null){worker=new HandlerThread("TankCameraWorker");worker.start();handler=new Handler(worker.getLooper());}
            cameraId=null;
            for(String id:manager.getCameraIdList()){
                CameraCharacteristics c=manager.getCameraCharacteristics(id);
                Integer facing=c.get(CameraCharacteristics.LENS_FACING);
                if(facing!=null && facing==CameraCharacteristics.LENS_FACING_BACK){cameraId=id;break;}
            }
            if(cameraId==null){message("Keine Rückkamera gefunden");return;}
            CameraCharacteristics c=manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map=c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if(map==null)throw new Exception("Keine Stream-Konfiguration");
            Size[] sizes=map.getOutputSizes(android.graphics.ImageFormat.JPEG);
            if(sizes==null||sizes.length==0)throw new Exception("JPEG nicht unterstützt");
            jpegSize=Collections.max(Arrays.asList(sizes),Comparator.comparingLong(x->(long)x.getWidth()*x.getHeight()));
            reader=ImageReader.newInstance(jpegSize.getWidth(),jpegSize.getHeight(),android.graphics.ImageFormat.JPEG,2);
            reader.setOnImageAvailableListener(r->{
                Image img=null;
                try {img=r.acquireNextImage();if(img==null)return;
                    ByteBuffer bb=img.getPlanes()[0].getBuffer();byte[] data=new byte[bb.remaining()];bb.get(data);saveImage(data);
                }catch(Exception e){message("Speicherfehler: "+e.getMessage());}
                finally{if(img!=null)img.close();busy=false;}
            },handler);
            manager.openCamera(cameraId,new CameraDevice.StateCallback(){
                public void onOpened(CameraDevice d){camera=d;createPreview();}
                public void onDisconnected(CameraDevice d){d.close();camera=null;message("Kamera getrennt");}
                public void onError(CameraDevice d,int error){d.close();camera=null;message("Kamerafehler: "+error);}
            },handler);
        }catch(Exception e){message("Startfehler: "+e.getMessage());}
    }
    private void createPreview(){
        try {
            SurfaceTexture texture=preview.getSurfaceTexture();if(texture==null)return;
            texture.setDefaultBufferSize(1280,720);
            Surface surface=new Surface(texture);
            repeating=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            repeating.addTarget(surface);
            repeating.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            repeating.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,exposure);
            camera.createCaptureSession(Arrays.asList(surface,reader.getSurface()),new CameraCaptureSession.StateCallback(){
                public void onConfigured(CameraCaptureSession s){session=s;refreshPreview();message("Bereit • JPEG "+jpegSize.getWidth()+" × "+jpegSize.getHeight()+" • EV "+exposure);}
                public void onConfigureFailed(CameraCaptureSession s){message("Vorschau-Konfiguration fehlgeschlagen");}
            },handler);
        }catch(Exception e){message("Vorschaufehler: "+e.getMessage());}
    }
    private void refreshPreview(){try{if(session!=null&&repeating!=null)session.setRepeatingRequest(repeating.build(),null,handler);}catch(Exception e){message(e.getMessage());}}
    private void setExposure(int ev){
        try {if(cameraId==null)return;CameraCharacteristics c=manager.getCameraCharacteristics(cameraId);
            android.util.Range<Integer> range=c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE);
            if(range==null)return;exposure=Math.max(range.getLower(),Math.min(range.getUpper(),ev));
            if(repeating!=null){repeating.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,exposure);refreshPreview();}
            message("EV-Stufe: "+exposure+" (Schrittweite geräteabhängig)");
        }catch(Exception e){message(e.getMessage());}
    }
    private void capture(){
        if(camera==null||session==null||busy)return;busy=true;
        try {
            CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.JPEG_QUALITY,(byte)100);
            b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,exposure);
            int rotation=getWindowManager().getDefaultDisplay().getRotation();
            int degrees=new int[]{0,90,180,270}[rotation];
            CameraCharacteristics c=manager.getCameraCharacteristics(cameraId);
            Integer sensor=c.get(CameraCharacteristics.SENSOR_ORIENTATION);
            b.set(CaptureRequest.JPEG_ORIENTATION,((sensor==null?90:sensor)-degrees+360)%360);
            session.capture(b.build(),new CameraCaptureSession.CaptureCallback(){
                @Override public void onCaptureFailed(CameraCaptureSession s,CaptureRequest r,CaptureFailure f){busy=false;message("Aufnahme fehlgeschlagen");}
            },handler);
            message("Foto wird aufgenommen …");
        }catch(Exception e){busy=false;message("Fotofehler: "+e.getMessage());}
    }
    private void saveImage(byte[] bytes)throws Exception{
        ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"TANK_"+System.currentTimeMillis()+".jpg");
        v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/TankCameraPro");
        Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
        if(uri==null)throw new Exception("MediaStore konnte Datei nicht anlegen");
        try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("Kein Dateistream");out.write(bytes);}
        message("Foto gespeichert • "+jpegSize.getWidth()+" × "+jpegSize.getHeight());
    }
    private void showDiagnostics(){
        try {StringBuilder sb=new StringBuilder();
            for(String id:manager.getCameraIdList()){
                CameraCharacteristics c=manager.getCameraCharacteristics(id);
                sb.append("Kamera ").append(id).append("\n");
                sb.append("Facing: ").append(c.get(CameraCharacteristics.LENS_FACING)).append("\n");
                sb.append("Hardware-Level: ").append(c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)).append("\n");
                int[] caps=c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES);
                sb.append("RAW: ").append(caps!=null&&contains(caps,CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)).append("\n");
                StreamConfigurationMap map=c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if(map!=null){Size[] sizes=map.getOutputSizes(android.graphics.ImageFormat.JPEG);
                    if(sizes!=null&&sizes.length>0){Size max=Collections.max(Arrays.asList(sizes),Comparator.comparingLong(x->(long)x.getWidth()*x.getHeight()));sb.append("JPEG max: ").append(max).append("\n");}}
                sb.append("\n");
            }
            runOnUiThread(()->new android.app.AlertDialog.Builder(this).setTitle("Camera2 Diagnose").setMessage(sb.toString()).setPositiveButton("OK",null).show());
        }catch(Exception e){message("Diagnosefehler: "+e.getMessage());}
    }
    private boolean contains(int[] a,int value){for(int i:a)if(i==value)return true;return false;}
    private void closeCamera(){if(session!=null){session.close();session=null;}if(camera!=null){camera.close();camera=null;}if(reader!=null){reader.close();reader=null;}}
    @Override protected void onPause(){closeCamera();super.onPause();}
    @Override protected void onResume(){super.onResume();if(preview!=null&&preview.isAvailable()&&camera==null&&checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();}
    @Override protected void onDestroy(){closeCamera();if(worker!=null){worker.quitSafely();worker=null;}super.onDestroy();}
    @Override public void onRequestPermissionsResult(int req,String[] permissions,int[] grants){super.onRequestPermissionsResult(req,permissions,grants);if(req==10&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED&&preview.isAvailable())startCamera();}
}
